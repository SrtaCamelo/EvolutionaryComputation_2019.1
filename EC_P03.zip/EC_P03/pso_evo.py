#Projeto 01, Evolutinary Computing
#Group Searsh Otimization Code
#Srta Camelo


#imports

import fitness as ft
import numpy as np
import math
import random

def a(v, best,c1, present):
    rand = random.uniform(0, 1)
    #v[] = v[] + c1 * rand() * (pbest[] - present[]) + c2 * rand() * (gbest[] - present[])
    v =  v + c1 * rand() * (best[0] - present) + c1 * rand * (best[0] - present)
    return v

def b(p,v):
    #present[] = persent[] + v[]
    p = p + v
    return p
def pso(population,x_train, y_train, x_test, y_test,x_validate,y_validate):
    # max_velocity = 0

    c1 = 1
    velocity = [0] * 20
    present = [0] * 20

    gbest = ft.find_best(population, x_train, y_train, x_validate, y_validate)
    num_generations = 50

    for k in range(num_generations):
        lbest = ft.find_best(population,x_train, y_train, x_validate, y_validate)
        print(gbest[1][0])
        if lbest[1][0] > gbest[1][0]:
            gbest = lbest
        for particleIdx in range(population):
            velocity[particleIdx] = a(velocity[particleIdx], gbest,c1,present[particleIdx])
            present[particleIdx] = b(present[particleIdx], velocity[particleIdx])

    best_accu = ft.fitness_best(gbest[0], gbest[1], x_test, y_test)
    # print(best_accu)
    return best_accu



